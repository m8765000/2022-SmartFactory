﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TeamProject_Server
{
    public partial class Form1 : Form
    {
        private static string strCon = @"Data Source=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=1521)))
                                    (CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=xe))); User Id = hr; Password = hr;";
        private OracleConnection conn;
        StreamReader streamReader1;
        StreamWriter streamWriter1;

        private delegate void Lookup();

        public Form1()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            Thread thread1 = new Thread(connect);
            thread1.IsBackground = true;
            thread1.Start();
        }

        private void OrderLookup(string Recv_Data)
        {
            try
            {
                if (conn == null)
                {
                    conn = new OracleConnection(strCon);
                }
                conn.Open();
                string bookInfo = $"SELECT * FROM SERVERDB_TABLE WHERE BOOK_NAME LIKE '%{Recv_Data}%'";
                DataTable ds = new DataTable(); 
                OracleDataAdapter adapt = new OracleDataAdapter(bookInfo, conn);
                adapt.Fill(ds);
                dataGridView1.DataSource = ds;

                conn.Close();
            }


            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void connect()
        {
            //IPAddress localAddr = IPAddress.Parse("127.0.0.1");
            TcpListener tcpListener1 = new TcpListener(IPAddress.Any, 12300);
            tcpListener1.Start();
            writeRichTextbox("서버 준비 클라이언트 연결중...");

            TcpClient tcpClient = tcpListener1.AcceptTcpClient();
            writeRichTextbox("클라이언트 연결됨");

            streamReader1 = new StreamReader(tcpClient.GetStream());
            streamWriter1 = new StreamWriter(tcpClient.GetStream());
            streamWriter1.AutoFlush = true;

            string Recv_Data = streamReader1.ReadLine();

            while (tcpClient.Connected)
            {
                Recv_Data = streamReader1.ReadLine();
                writeRichTextbox(Recv_Data);
                OrderLookup(Recv_Data);
            }
        }

        public void writeRichTextbox(string str)
        {
            richTextBox1.Invoke((MethodInvoker)
                delegate { richTextBox1.AppendText(str + "\r\n"); });
            richTextBox1.Invoke((MethodInvoker)
                delegate { richTextBox1.ScrollToCaret(); });
        }

        private void 폼2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.ShowDialog();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void 폼3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                if (conn == null)
                {
                    conn = new OracleConnection(strCon);
                }
                conn.Open();
                string bookInfo = $"UPDATE SERVERDB_TABLE SET STOCK_QUANTITY = STOCK_QUANTITY -1 WHERE BOOK_NAME = '{Recv_Data}'";
                DataTable ds = new DataTable();
                OracleDataAdapter adapt = new OracleDataAdapter(bookInfo, conn);
                adapt.Fill(ds);
                dataGridView1.DataSource = ds;

                conn.Close();
            }


            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
    
