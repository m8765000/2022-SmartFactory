﻿namespace TeamProject_Server
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.button6 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.button16 = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.button22 = new System.Windows.Forms.Button();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel15.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(230, 70);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(360, 258);
            this.dataGridView1.TabIndex = 18;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(230, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 25);
            this.label1.TabIndex = 17;
            this.label1.Text = "주문현황";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(596, 70);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(192, 124);
            this.richTextBox1.TabIndex = 16;
            this.richTextBox1.Text = "";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.HorizontalScrollbar = true;
            this.listBox1.ItemHeight = 12;
            this.listBox1.Location = new System.Drawing.Point(596, 225);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(192, 88);
            this.listBox1.TabIndex = 20;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(15, 19);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(150, 59);
            this.button6.TabIndex = 0;
            this.button6.Text = "파일";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(26, 180);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(125, 43);
            this.button13.TabIndex = 0;
            this.button13.Text = "종료";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(26, 125);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(125, 43);
            this.button14.TabIndex = 0;
            this.button14.Text = "로그 아웃";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(26, 70);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(125, 43);
            this.button15.TabIndex = 0;
            this.button15.Text = "환경 설정";
            this.button15.UseVisualStyleBackColor = true;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel8.Controls.Add(this.button13);
            this.panel8.Controls.Add(this.button14);
            this.panel8.Controls.Add(this.button15);
            this.panel8.Controls.Add(this.button16);
            this.panel8.Location = new System.Drawing.Point(1, 90);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(180, 263);
            this.panel8.TabIndex = 1;
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(26, 15);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(125, 43);
            this.button16.TabIndex = 0;
            this.button16.Text = "프린터 설정";
            this.button16.UseVisualStyleBackColor = true;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel9.Controls.Add(this.panel8);
            this.panel9.Controls.Add(this.button6);
            this.panel9.Location = new System.Drawing.Point(15, 24);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(182, 354);
            this.panel9.TabIndex = 0;
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(15, 19);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(150, 59);
            this.button17.TabIndex = 0;
            this.button17.Text = "기술부";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(26, 84);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(125, 43);
            this.button18.TabIndex = 0;
            this.button18.Text = "PM";
            this.button18.UseVisualStyleBackColor = true;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel10.Controls.Add(this.panel11);
            this.panel10.Controls.Add(this.button17);
            this.panel10.Location = new System.Drawing.Point(15, 115);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(182, 248);
            this.panel10.TabIndex = 0;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel11.Controls.Add(this.button18);
            this.panel11.Controls.Add(this.button19);
            this.panel11.Location = new System.Drawing.Point(1, 90);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(180, 157);
            this.panel11.TabIndex = 1;
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(26, 35);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(125, 43);
            this.button19.TabIndex = 0;
            this.button19.Text = "엔지니어";
            this.button19.UseVisualStyleBackColor = true;
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(15, 19);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(150, 59);
            this.button20.TabIndex = 0;
            this.button20.Text = "영업부";
            this.button20.UseVisualStyleBackColor = true;
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(26, 35);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(125, 43);
            this.button21.TabIndex = 0;
            this.button21.Text = "프로젝트 관리";
            this.button21.UseVisualStyleBackColor = true;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel12.Controls.Add(this.button21);
            this.panel12.Location = new System.Drawing.Point(1, 90);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(180, 157);
            this.panel12.TabIndex = 1;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel13.Controls.Add(this.panel12);
            this.panel13.Controls.Add(this.button20);
            this.panel13.Location = new System.Drawing.Point(15, 206);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(182, 202);
            this.panel13.TabIndex = 0;
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(15, 19);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(150, 59);
            this.button22.TabIndex = 0;
            this.button22.Text = "데이터베이스 관리";
            this.button22.UseVisualStyleBackColor = true;
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel14.Controls.Add(this.button22);
            this.panel14.Location = new System.Drawing.Point(15, 297);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(182, 99);
            this.panel14.TabIndex = 0;
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.panel14);
            this.panel15.Controls.Add(this.panel13);
            this.panel15.Controls.Add(this.panel10);
            this.panel15.Controls.Add(this.panel9);
            this.panel15.Location = new System.Drawing.Point(4, 27);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(220, 761);
            this.panel15.TabIndex = 22;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1106, 739);
            this.Controls.Add(this.panel15);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.listBox1);
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel15;
    }
}