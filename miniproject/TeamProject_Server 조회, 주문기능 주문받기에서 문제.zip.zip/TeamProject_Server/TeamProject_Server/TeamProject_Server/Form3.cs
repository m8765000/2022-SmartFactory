﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TeamProject_Server
{
    public partial class Form3 : Form
    {
        int cnt = 0;

        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
        private static DateTime Delay(int MS)
        {
            DateTime ThisMoment = DateTime.Now;
            TimeSpan duration = new TimeSpan(0, 0, 0, 0, MS);
            DateTime AfterWards = ThisMoment.Add(duration);

            while (AfterWards >= ThisMoment)
            {
                System.Windows.Forms.Application.DoEvents();
                ThisMoment = DateTime.Now;
            }

            return DateTime.Now;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            int i = 5;
            cnt++;
            while(i< 240)
            {
                Delay(5);
                panel9.Location = new Point(15, 115 + i);
                panel11.Location = new Point(15, 206 + i);
                panel13.Location = new Point(15, 297 + i);
                i += 5;
            }
            if (cnt == 2)
            {
                i = 100;
                Delay(5);
                panel9.Location = new Point(15, 115 + i);
                panel11.Location = new Point(15, 206 + i);
                panel13.Location = new Point(15, 297 + i);
                cnt = 0;
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            int i = 5;
            cnt++;
            while (i < 240)
            {
                Delay(5);
                panel8.Location = new Point(15, 115 + i);
                panel10.Location = new Point(15, 206 + i);
                panel12.Location = new Point(15, 297 + i);
                i += 5;
            }
        }
    }
}
