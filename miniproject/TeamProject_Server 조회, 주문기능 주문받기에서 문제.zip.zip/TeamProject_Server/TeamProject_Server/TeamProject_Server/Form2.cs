﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TeamProject_Server
{
    public partial class Form2 : Form
    {
        private static string strCon = @"Data Source=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=1521)))
                                    (CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=xe))); User Id = hr; Password = hr;";
        private OracleConnection conn;

        private delegate void Lookup();
        private delegate void Order1();
        private delegate void BookName();

        public Form2()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;
        }
        private void DataLookup()
        {
            try
            {
                if (conn == null)
                {
                    conn = new OracleConnection(strCon);
                }
                conn.Open();
                string bookInfo = "SELECT * FROM SERVERDB_TABLE";
                DataSet ds = new DataSet();
                OracleDataAdapter adapt = new OracleDataAdapter(bookInfo, conn);
                adapt.Fill(ds);
                dataGridView1.DataSource = ds.Tables[0];

                    conn.Close();

                
                dataGridView1.Refresh();
            }


            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Order()
        {
            try
            {
                if (conn == null)
                {
                    conn = new OracleConnection(strCon);
                }
                conn.Open();
                string bookInfo = $"UPDATE SERVERDB_TABLE SET STOCK_QUANTITY = {numericUpDown1.Value}";
                DataTable ds = new DataTable(); //set안쓰고 테이블로 고치니까 에러 안나고 잘됨
                OracleDataAdapter adapt = new OracleDataAdapter(bookInfo, conn);
                adapt.Fill(ds);
                
                dataGridView1.DataSource = ds;

                    conn.Close();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Order_One_Book()
        {
            try
            {
                if (conn == null)
                {
                    conn = new OracleConnection(strCon);
                }
                conn.Open();
                string bookInfo = $"UPDATE SERVERDB_TABLE SET STOCK_QUANTITY = {numericUpDown1.Value} WHERE BOOK_NAME = '{listBox1.Text}'";
                DataTable ds = new DataTable(); //set안쓰고 테이블로 고치니까 에러 안나고 잘됨
                OracleDataAdapter adapt = new OracleDataAdapter(bookInfo, conn);
                adapt.Fill(ds);

                dataGridView1.DataSource = ds;

                conn.Close();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void Lookup_btn_Click(object sender, EventArgs e)
        {
            Lookup lookup = new Lookup(DataLookup);
            lookup();
            BookName bookname = new BookName(Book_name);
            bookname();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Order1 order = new Order1(Order);
            order();
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Order1 orderonebook = new Order1(Order_One_Book);
            orderonebook();
        }

        private void Book_name()
        {
            try
            {
                if (conn == null)
                {
                    conn = new OracleConnection(strCon);
                }
                conn.Open();
                string BOOK_NAME = "SELECT BOOK_NAME FROM BOOKINFO_TABLE";
                OracleDataAdapter adapt = new OracleDataAdapter();
                adapt.SelectCommand = new OracleCommand(BOOK_NAME, conn);
                DataSet ds = new DataSet();
                adapt.Fill(ds);

                listBox1.DataSource = ds.Tables[0];
                listBox1.DisplayMember = "BOOK_NAME";

                conn.Close();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
